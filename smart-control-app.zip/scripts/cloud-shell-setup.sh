#!/bin/bash

echo "=== Flashback Cloud Shell Setup ==="
echo ""

# Update package list
echo "Updating packages..."
sudo apt-get update -qq

# Install Node.js
echo "Installing Node.js..."
if ! command -v node &> /dev/null; then
    curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
    sudo apt-get install -y nodejs
fi

echo "Node version: $(node --version)"
echo "NPM version: $(npm --version)"

# Install Flutter (optional - for building APK)
echo ""
echo "Installing Flutter..."
if ! command -v flutter &> /dev/null; then
    git clone https://github.com/flutter/flutter.git -b stable --depth 1
    export PATH="$PATH:$(pwd)/flutter/bin"
    flutter doctor
fi

# Setup backend
echo ""
echo "Setting up backend..."
cd backend
npm install
cp .env.example .env

echo ""
echo "Backend setup complete!"
echo "Edit .env file with your configuration"
echo ""
echo "To start:"
echo "  cd backend"
echo "  node keep-alive.js &"
echo "  npm start"
echo ""
echo "To setup AI:"
echo "  cd ollama-setup"
echo "  ./setup-ollama.sh"
