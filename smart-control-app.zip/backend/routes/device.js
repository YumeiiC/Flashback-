const express = require('express');
const router = express.Router();
const { authenticateToken } = require('../middleware/auth');
const db = require('../config/database');

// Get all devices (admin sees all, user sees own paired)
router.get('/', authenticateToken, function(req, res) {
  let query = 'SELECT * FROM devices';
  let params = [];

  if (req.user.role !== 'admin') {
    query = query + ' WHERE paired_by = ?';
    params = [req.user.id];
  }

  query = query + ' ORDER BY created_at DESC';

  db.all(query, params, function(err, rows) {
    if (err) {
      return res.status(500).json({ error: 'Failed to fetch devices' });
    }
    res.json(rows);
  });
});

// Get single device
router.get('/:deviceId', authenticateToken, function(req, res) {
  const deviceId = req.params.deviceId;

  db.get(
    'SELECT * FROM devices WHERE device_id = ?',
    [deviceId],
    function(err, device) {
      if (err || !device) {
        return res.status(404).json({ error: 'Device not found' });
      }

      if (req.user.role !== 'admin' && device.paired_by !== req.user.id) {
        return res.status(403).json({ error: 'Access denied' });
      }

      res.json(device);
    }
  );
});

// Update device status
router.put('/:deviceId/status', authenticateToken, function(req, res) {
  const deviceId = req.params.deviceId;
  const { status, battery, signal, storage, lat, lng } = req.body;

  db.run(
    'UPDATE devices SET status = ?, battery = ?, signal_strength = ?, storage_used = ?, location_lat = ?, location_lng = ?, last_seen = CURRENT_TIMESTAMP WHERE device_id = ?',
    [status, battery, signal, storage, lat, lng, deviceId],
    function(err) {
      if (err) {
        return res.status(500).json({ error: 'Update failed' });
      }

      // Save location history
      if (lat && lng) {
        db.run(
          'INSERT INTO location_history (device_id, lat, lng) VALUES (?, ?, ?)',
          [deviceId, lat, lng]
        );
      }

      res.json({ success: true });
    }
  );
});

// Delete device
router.delete('/:deviceId', authenticateToken, function(req, res) {
  const deviceId = req.params.deviceId;

  db.get(
    'SELECT * FROM devices WHERE device_id = ?',
    [deviceId],
    function(err, device) {
      if (err || !device) {
        return res.status(404).json({ error: 'Device not found' });
      }

      if (req.user.role !== 'admin' && device.paired_by !== req.user.id) {
        return res.status(403).json({ error: 'Access denied' });
      }

      db.run('DELETE FROM devices WHERE device_id = ?', [deviceId], function(err) {
        if (err) {
          return res.status(500).json({ error: 'Delete failed' });
        }
        res.json({ success: true });
      });
    }
  );
});

module.exports = router;
