const express = require('express');
const router = express.Router();
const { authenticateToken } = require('../middleware/auth');
const db = require('../config/database');

// Send control command to device
router.post('/:deviceId/:action', authenticateToken, function(req, res) {
  const deviceId = req.params.deviceId;
  const action = req.params.action;
  const io = req.app.get('io');
  const connectedDevices = req.app.get('connectedDevices');

  // Verify access
  db.get(
    'SELECT * FROM devices WHERE device_id = ?',
    [deviceId],
    function(err, device) {
      if (err || !device) {
        return res.status(404).json({ error: 'Device not found' });
      }

      if (req.user.role !== 'admin' && device.paired_by !== req.user.id) {
        return res.status(403).json({ error: 'Access denied' });
      }

      // Log action
      db.run(
        'INSERT INTO logs (user_id, device_id, action, details) VALUES (?, ?, ?, ?)',
        [req.user.id, deviceId, action, JSON.stringify(req.body)]
      );

      // Send command via socket
      const socketId = connectedDevices[deviceId];
      if (socketId) {
        io.to(socketId).emit('control_command', {
          action: action,
          params: req.body,
          from: req.user.email,
          timestamp: new Date().toISOString()
        });
        res.json({ success: true, message: 'Command sent to device' });
      } else {
        res.status(404).json({ error: 'Device offline' });
      }
    }
  );
});

// Available actions
router.get('/actions', authenticateToken, function(req, res) {
  res.json([
    { id: 'flashlight_on', name: 'Flashlight ON', icon: 'flashlight', category: 'hardware' },
    { id: 'flashlight_off', name: 'Flashlight OFF', icon: 'flashlight-off', category: 'hardware' },
    { id: 'play_sound', name: 'Play Sound / Alarm', icon: 'volume-high', category: 'audio' },
    { id: 'stop_sound', name: 'Stop Sound', icon: 'volume-off', category: 'audio' },
    { id: 'capture_photo', name: 'Capture Photo', icon: 'camera', category: 'camera' },
    { id: 'start_record', name: 'Start Screen Record', icon: 'record-circle', category: 'screen' },
    { id: 'stop_record', name: 'Stop Screen Record', icon: 'stop-circle', category: 'screen' },
    { id: 'get_location', name: 'Get Location', icon: 'map-marker', category: 'location' },
    { id: 'get_files', name: 'List Files', icon: 'folder', category: 'files' },
    { id: 'get_notifications', name: 'Get Notifications', icon: 'bell', category: 'system' },
    { id: 'device_info', name: 'Device Info', icon: 'information', category: 'system' },
    { id: 'vibrate', name: 'Vibrate', icon: 'vibrate', category: 'hardware' }
  ]);
});

module.exports = router;
