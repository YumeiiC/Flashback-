const express = require('express');
const router = express.Router();
const axios = require('axios');
const { authenticateToken } = require('../middleware/auth');

const OLLAMA_URL = process.env.OLLAMA_URL || 'http://localhost:11434';
const OLLAMA_MODEL = process.env.OLLAMA_MODEL || 'phi3';
const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
const GEMINI_FALLBACK = process.env.GEMINI_FALLBACK === 'true';

// Chat with AI
router.post('/chat', authenticateToken, async function(req, res) {
  const { message, history } = req.body;

  if (!message) {
    return res.status(400).json({ error: 'Message required' });
  }

  // Try Ollama first
  try {
    const response = await axios.post(
      OLLAMA_URL + '/api/generate',
      {
        model: OLLAMA_MODEL,
        prompt: buildPrompt(message, history),
        stream: false
      },
      { timeout: 30000 }
    );

    res.json({
      response: response.data.response,
      source: 'ollama',
      model: OLLAMA_MODEL
    });
  } catch (ollamaErr) {
    console.log('Ollama failed: ' + ollamaErr.message);

    // Fallback to Gemini
    if (GEMINI_FALLBACK && GEMINI_API_KEY) {
      try {
        const geminiResponse = await axios.post(
          'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=' + GEMINI_API_KEY,
          {
            contents: [{
              parts: [{ text: message }]
            }]
          },
          { timeout: 30000 }
        );

        const geminiText = geminiResponse.data.candidates[0].content.parts[0].text;
        res.json({
          response: geminiText,
          source: 'gemini',
          model: 'gemini-pro'
        });
      } catch (geminiErr) {
        console.log('Gemini fallback failed: ' + geminiErr.message);
        res.status(500).json({
          error: 'AI service unavailable',
          details: 'Both Ollama and Gemini failed. Please check your configuration.'
        });
      }
    } else {
      res.status(500).json({
        error: 'AI service unavailable',
        details: 'Ollama is not running. Please start Ollama or configure Gemini fallback.'
      });
    }
  }
});

// Check AI status
router.get('/status', async function(req, res) {
  try {
    const response = await axios.get(OLLAMA_URL + '/api/tags', { timeout: 5000 });
    res.json({
      ollama: true,
      models: response.data.models || [],
      currentModel: OLLAMA_MODEL
    });
  } catch (err) {
    res.json({
      ollama: false,
      error: err.message,
      geminiConfigured: !!GEMINI_API_KEY
    });
  }
});

function buildPrompt(message, history) {
  let prompt = 'You are a helpful AI assistant for Smart Control App. You can help users control their devices.\n\n';

  if (history && history.length > 0) {
    history.forEach(function(h) {
      prompt = prompt + 'User: ' + h.user + '\n';
      prompt = prompt + 'Assistant: ' + h.assistant + '\n';
    });
  }

  prompt = prompt + 'User: ' + message + '\n';
  prompt = prompt + 'Assistant:';

  return prompt;
}

module.exports = router;
