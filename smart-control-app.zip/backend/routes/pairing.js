const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const QRCode = require('qrcode');
const { authenticateToken } = require('../middleware/auth');
const db = require('../config/database');

// Generate pairing code (OTP)
router.post('/code', authenticateToken, function(req, res) {
  const { phoneNumber, deviceName } = req.body;
  const code = Math.floor(100000 + Math.random() * 900000).toString();
  const deviceId = uuidv4();
  const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

  db.run(
    'INSERT INTO pairing_codes (code, device_id, phone_number, expires_at) VALUES (?, ?, ?, ?)',
    [code, deviceId, phoneNumber, expiresAt.toISOString()],
    function(err) {
      if (err) {
        return res.status(500).json({ error: 'Failed to generate code' });
      }

      // Also create device entry
      db.run(
        'INSERT INTO devices (device_id, name, phone_number, paired_by, status) VALUES (?, ?, ?, ?, ?)',
        [deviceId, deviceName || 'New Device', phoneNumber, req.user.id, 'pending'],
        function(err2) {
          if (err2) {
            console.error('Device creation error: ' + err2.message);
          }
        }
      );

      res.json({
        code: code,
        deviceId: deviceId,
        expiresAt: expiresAt.toISOString()
      });
    }
  );
});

// Verify pairing code
router.post('/verify', function(req, res) {
  const { code, deviceId } = req.body;

  db.get(
    'SELECT * FROM pairing_codes WHERE code = ? AND device_id = ? AND used = 0 AND expires_at > datetime("now")',
    [code, deviceId],
    function(err, row) {
      if (err || !row) {
        return res.status(400).json({ error: 'Invalid or expired code' });
      }

      db.run(
        'UPDATE pairing_codes SET used = 1 WHERE id = ?',
        [row.id],
        function(err) {
          if (err) {
            return res.status(500).json({ error: 'Verification failed' });
          }

          // Update device status
          db.run(
            'UPDATE devices SET status = ? WHERE device_id = ?',
            ['online', deviceId]
          );

          res.json({ success: true, deviceId: deviceId });
        }
      );
    }
  );
});

// Generate QR code
router.post('/qr', authenticateToken, function(req, res) {
  const { deviceName } = req.body;
  const deviceId = uuidv4();
  const pairingData = JSON.stringify({
    deviceId: deviceId,
    serverUrl: req.protocol + '://' + req.get('host'),
    timestamp: Date.now()
  });

  QRCode.toDataURL(pairingData, function(err, url) {
    if (err) {
      return res.status(500).json({ error: 'QR generation failed' });
    }

    // Create device entry
    db.run(
      'INSERT INTO devices (device_id, name, paired_by, status) VALUES (?, ?, ?, ?)',
      [deviceId, deviceName || 'New Device', req.user.id, 'pending'],
      function(err) {
        if (err) {
          console.error('Device creation error: ' + err.message);
        }
      }
    );

    res.json({
      qrCode: url,
      deviceId: deviceId
    });
  });
});

// Verify QR pairing
router.post('/qr-verify', function(req, res) {
  const { deviceId } = req.body;

  db.get(
    'SELECT * FROM devices WHERE device_id = ? AND status = ?',
    [deviceId, 'pending'],
    function(err, device) {
      if (err || !device) {
        return res.status(400).json({ error: 'Invalid device or already paired' });
      }

      db.run(
        'UPDATE devices SET status = ? WHERE device_id = ?',
        ['online', deviceId],
        function(err) {
          if (err) {
            return res.status(500).json({ error: 'Pairing failed' });
          }
          res.json({ success: true, deviceId: deviceId });
        }
      );
    }
  );
});

module.exports = router;
