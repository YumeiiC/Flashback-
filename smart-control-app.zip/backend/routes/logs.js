const express = require('express');
const router = express.Router();
const { authenticateToken, requireAdmin } = require('../middleware/auth');
const db = require('../config/database');

// Get all logs (admin only)
router.get('/', authenticateToken, requireAdmin, function(req, res) {
  const { deviceId, action, dateFrom, dateTo, limit } = req.query;

  let query = `
    SELECT logs.*, users.email as user_email, users.name as user_name
    FROM logs
    LEFT JOIN users ON logs.user_id = users.id
    WHERE 1=1
  `;
  let params = [];

  if (deviceId) {
    query = query + ' AND logs.device_id = ?';
    params.push(deviceId);
  }
  if (action) {
    query = query + ' AND logs.action = ?';
    params.push(action);
  }
  if (dateFrom) {
    query = query + ' AND logs.created_at >= ?';
    params.push(dateFrom);
  }
  if (dateTo) {
    query = query + ' AND logs.created_at <= ?';
    params.push(dateTo);
  }

  query = query + ' ORDER BY logs.created_at DESC';

  const limitNum = parseInt(limit) || 100;
  query = query + ' LIMIT ?';
  params.push(limitNum);

  db.all(query, params, function(err, rows) {
    if (err) {
      return res.status(500).json({ error: 'Failed to fetch logs' });
    }
    res.json(rows);
  });
});

// Get logs stats
router.get('/stats', authenticateToken, requireAdmin, function(req, res) {
  db.all(
    'SELECT action, COUNT(*) as count FROM logs GROUP BY action ORDER BY count DESC',
    [],
    function(err, actions) {
      if (err) {
        return res.status(500).json({ error: 'Stats failed' });
      }

      db.get(
        'SELECT COUNT(*) as total FROM logs',
        [],
        function(err, total) {
          if (err) {
            return res.status(500).json({ error: 'Stats failed' });
          }

          db.all(
            'SELECT date(created_at) as date, COUNT(*) as count FROM logs GROUP BY date(created_at) ORDER BY date DESC LIMIT 7',
            [],
            function(err, daily) {
              if (err) {
                return res.status(500).json({ error: 'Stats failed' });
              }

              res.json({
                total: total.total,
                actions: actions,
                daily: daily
              });
            }
          );
        }
      );
    }
  );
});

// Get location history for device
router.get('/location/:deviceId', authenticateToken, function(req, res) {
  const deviceId = req.params.deviceId;
  const { days } = req.query;
  const daysNum = parseInt(days) || 7;

  db.get(
    'SELECT * FROM devices WHERE device_id = ?',
    [deviceId],
    function(err, device) {
      if (err || !device) {
        return res.status(404).json({ error: 'Device not found' });
      }

      if (req.user.role !== 'admin' && device.paired_by !== req.user.id) {
        return res.status(403).json({ error: 'Access denied' });
      }

      const since = new Date(Date.now() - daysNum * 24 * 60 * 60 * 1000).toISOString();

      db.all(
        'SELECT * FROM location_history WHERE device_id = ? AND timestamp > ? ORDER BY timestamp DESC',
        [deviceId, since],
        function(err, rows) {
          if (err) {
            return res.status(500).json({ error: 'Failed to fetch location history' });
          }
          res.json(rows);
        }
      );
    }
  );
});

module.exports = router;
