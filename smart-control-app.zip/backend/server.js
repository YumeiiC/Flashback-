const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const cors = require('cors');
const path = require('path');
require('dotenv').config();

const db = require('./config/database');
const authRoutes = require('./routes/auth');
const deviceRoutes = require('./routes/device');
const pairingRoutes = require('./routes/pairing');
const controlRoutes = require('./routes/control');
const logRoutes = require('./routes/logs');
const aiRoutes = require('./routes/ai');

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
});

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Attach io to requests
app.use(function(req, res, next) {
  req.io = io;
  next();
});

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/devices', deviceRoutes);
app.use('/api/pairing', pairingRoutes);
app.use('/api/control', controlRoutes);
app.use('/api/logs', logRoutes);
app.use('/api/ai', aiRoutes);

// Health check
app.get('/api/health', function(req, res) {
  res.json({ status: 'ok', time: new Date().toISOString() });
});

// Socket.io handling
const connectedDevices = {};

io.on('connection', function(socket) {
  console.log('Client connected: ' + socket.id);

  socket.on('register_device', function(data) {
    connectedDevices[data.deviceId] = socket.id;
    socket.deviceId = data.deviceId;
    console.log('Device registered: ' + data.deviceId);
  });

  socket.on('device_status', function(data) {
    io.emit('status_update', {
      deviceId: socket.deviceId,
      battery: data.battery,
      signal: data.signal,
      storage: data.storage,
      location: data.location,
      timestamp: new Date().toISOString()
    });
  });

  socket.on('disconnect', function() {
    if (socket.deviceId) {
      delete connectedDevices[socket.deviceId];
      console.log('Device disconnected: ' + socket.deviceId);
    }
  });
});

// Make io global
app.set('io', io);
app.set('connectedDevices', connectedDevices);

const PORT = process.env.PORT || 3000;
server.listen(PORT, function() {
  console.log('Server running on port ' + PORT);
});
