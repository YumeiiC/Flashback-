const axios = require('axios');

const OLLAMA_URL = process.env.OLLAMA_URL || 'http://localhost:11434';

async function checkOllama() {
  try {
    await axios.get(OLLAMA_URL + '/api/tags', { timeout: 5000 });
    return true;
  } catch (err) {
    return false;
  }
}

async function generateResponse(prompt, model) {
  const response = await axios.post(
    OLLAMA_URL + '/api/generate',
    {
      model: model || 'phi3',
      prompt: prompt,
      stream: false
    },
    { timeout: 30000 }
  );
  return response.data.response;
}

module.exports = { checkOllama, generateResponse };
