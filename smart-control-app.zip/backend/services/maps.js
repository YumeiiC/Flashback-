// Google Maps service
const axios = require('axios');

const MAPS_API_KEY = process.env.MAPS_API_KEY;

async function geocodeAddress(address) {
  if (!MAPS_API_KEY) {
    throw new Error('Maps API key not configured');
  }

  const response = await axios.get(
    'https://maps.googleapis.com/maps/api/geocode/json?address=' + encodeURIComponent(address) + '&key=' + MAPS_API_KEY
  );
  return response.data;
}

async function reverseGeocode(lat, lng) {
  if (!MAPS_API_KEY) {
    throw new Error('Maps API key not configured');
  }

  const response = await axios.get(
    'https://maps.googleapis.com/maps/api/geocode/json?latlng=' + lat + ',' + lng + '&key=' + MAPS_API_KEY
  );
  return response.data;
}

module.exports = { geocodeAddress, reverseGeocode };
