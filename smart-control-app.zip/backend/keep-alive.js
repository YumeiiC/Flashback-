const http = require('http');
const cron = require('node-cron');

const TARGET_URL = 'http://localhost:3000';
const PING_INTERVAL = 5; // minutes

console.log('Keep-alive service started');
console.log('Pinging every ' + PING_INTERVAL + ' minutes');

cron.schedule('*/' + PING_INTERVAL + ' * * * *', function() {
  const req = http.get(TARGET_URL + '/api/health', function(res) {
    console.log('Ping successful: ' + res.statusCode);
  });

  req.on('error', function(err) {
    console.log('Ping failed: ' + err.message);
  });

  req.setTimeout(10000, function() {
    req.destroy();
  });
});

// Health check endpoint
const express = require('express');
const app = express();

app.get('/health', function(req, res) {
  res.json({ status: 'ok', time: new Date().toISOString() });
});

app.listen(3001, function() {
  console.log('Keep-alive health check on port 3001');
});
