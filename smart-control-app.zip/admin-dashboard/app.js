const API_URL = 'http://localhost:3000/api';

// Navigation
const navLinks = document.querySelectorAll('nav a');
navLinks.forEach(function(link) {
  link.addEventListener('click', function(e) {
    e.preventDefault();
    navLinks.forEach(function(l) { l.classList.remove('active'); });
    this.classList.add('active');
  });
});

// View all links
const viewAllLinks = document.querySelectorAll('.view-all');
viewAllLinks.forEach(function(link) {
  link.addEventListener('click', function(e) {
    e.preventDefault();
    const page = this.getAttribute('data-page');
    navLinks.forEach(function(l) { l.classList.remove('active'); });
    document.querySelector('nav a[data-page="' + page + '"]').classList.add('active');
  });
});

async function fetchData(endpoint) {
  try {
    const response = await fetch(API_URL + endpoint, {
      headers: {
        'Authorization': 'Bearer ' + getToken()
      }
    });
    if (!response.ok) throw new Error('Request failed');
    return await response.json();
  } catch (err) {
    console.error('Fetch error:', err);
    return null;
  }
}

function getToken() {
  return localStorage.getItem('token') || '';
}

async function refreshData() {
  // Fetch devices
  const devices = await fetchData('/devices');
  if (devices) {
    document.getElementById('totalDevices').textContent = devices.length;
    const onlineCount = devices.filter(function(d) { return d.status === 'online'; }).length;
    document.getElementById('onlineDevices').textContent = onlineCount;
    renderDeviceList(devices.slice(0, 5));
  }

  // Fetch logs stats
  const logsStats = await fetchData('/logs/stats');
  if (logsStats) {
    document.getElementById('totalLogs').textContent = logsStats.total || 0;
  }

  // Fetch AI status
  const aiStatus = await fetchData('/ai/status');
  if (aiStatus) {
    document.getElementById('aiStatus').textContent = aiStatus.ollama ? 'ON' : 'OFF';
    document.getElementById('aiStatus').style.color = aiStatus.ollama ? 'var(--success)' : 'var(--danger)';
  }

  // Fetch recent logs
  const logs = await fetchData('/logs?limit=5');
  if (logs) {
    renderLogList(logs);
  }
}

function renderDeviceList(devices) {
  const container = document.getElementById('deviceList');
  if (!devices || devices.length === 0) {
    container.innerHTML = '<div class="empty-state">No devices connected</div>';
    return;
  }
  container.innerHTML = devices.map(function(device) {
    return '<div class="device-item">' +
      '<div class="device-status ' + (device.status === 'online' ? 'online' : 'offline') + '"></div>' +
      '<div class="device-info">' +
        '<div class="device-name">' + (device.name || 'Unknown') + '</div>' +
        '<div class="device-meta">' + (device.phone_number || 'No number') + ' | Battery: ' + (device.battery || '--') + '%</div>' +
      '</div>' +
    '</div>';
  }).join('');
}

function renderLogList(logs) {
  const container = document.getElementById('logList');
  if (!logs || logs.length === 0) {
    container.innerHTML = '<div class="empty-state">No logs available</div>';
    return;
  }
  container.innerHTML = logs.map(function(log) {
    return '<div class="log-item">' +
      '<div class="log-info">' +
        '<div class="log-action">' + (log.action || 'Unknown') + '</div>' +
        '<div class="log-meta">Device: ' + (log.device_id || 'N/A') + ' | By: ' + (log.user_email || 'Unknown') + '</div>' +
      '</div>' +
    '</div>';
  }).join('');
}

// Initial load
refreshData();

// Auto refresh every 30 seconds
setInterval(refreshData, 30000);
