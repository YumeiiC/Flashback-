#!/bin/bash

echo "Installing Phi-3 Mini model..."

if ! command -v ollama &> /dev/null; then
    echo "Ollama not found. Run setup-ollama.sh first."
    exit 1
fi

ollama pull phi3
echo "Phi-3 Mini installed successfully!"
