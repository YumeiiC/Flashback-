#!/bin/bash

echo "=== Flashback AI Setup ==="
echo "Installing Ollama..."

# Check if Ollama is installed
if command -v ollama &> /dev/null; then
    echo "Ollama already installed"
else
    # Install Ollama
    curl -fsSL https://ollama.com/install.sh | sh
fi

# Start Ollama in background
echo "Starting Ollama..."
nohup ollama serve > ollama.log 2>&1 &
sleep 5

# Pull Phi-3 Mini model
echo "Downloading Phi-3 Mini model (this may take a while)..."
ollama pull phi3

echo ""
echo "=== Setup Complete ==="
echo "Ollama is running at http://localhost:11434"
echo "Model: phi3"
echo ""
echo "To check status: curl http://localhost:11434/api/tags"
echo "To test AI: curl http://localhost:11434/api/generate -d '{"model":"phi3","prompt":"Hello"}'"
