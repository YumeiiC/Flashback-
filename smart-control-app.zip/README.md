# Smart Control App - Flashback

Aplikasi kontrol HP Android jarak jauh dengan AI, Google Maps, dan fitur pantau lengkap.

## Fitur
- Pairing via QR Code & No HP + OTP
- Kontrol HP: Flashlight, Kamera, Screen Record, Lokasi, Suara, File Manager
- AI Chat (Phi-3 Mini self-hosted / Gemini fallback)
- Google Maps real-time tracking
- Admin Dashboard dengan logs & resource monitoring
- Dark/Light mode

## Setup di Google Cloud Shell

### 1. Clone Repo
```bash
git clone https://github.com/YumeiiC/Flashback-.git
cd Flashback-
```

### 2. Unzip File
```bash
unzip smart-control-app.zip
```

### 3. Setup Backend
```bash
cd backend
npm install
cp .env.example .env
# Edit .env dengan konfigurasi lo
```

### 4. Setup Ollama (AI)
```bash
cd ../ollama-setup
chmod +x setup-ollama.sh
./setup-ollama.sh
```

### 5. Jalankan Backend
```bash
cd backend
node keep-alive.js &
npm start
```

### 6. Setup Android App
```bash
cd ../android-app
flutter pub get
flutter build apk
```

## Konfigurasi

### Google Maps API Key
1. Buka https://console.cloud.google.com/
2. Buat project baru atau pilih existing
3. Enable "Maps SDK for Android"
4. Buat API Key di Credentials
5. Masukkan ke `android-app/android/app/src/main/AndroidManifest.xml`

### Firebase
1. Buka https://console.firebase.google.com/
2. Buat project baru
3. Download `google-services.json`
4. Taruh di `android-app/android/app/`

### Ollama AI
Backend akan otomatis coba connect ke Ollama local.
Jika gagal (RAM tidak cukup), akan fallback ke Gemini API free tier.

## Cloud Shell Keep Alive
Cloud Shell mati jika idle 1 jam. Jalankan:
```bash
node backend/keep-alive.js
```

## Struktur Folder
```
backend/         - Node.js API server
android-app/     - Flutter Android app
admin-dashboard/ - Web admin panel
ollama-setup/    - AI setup scripts
```

## Tech Stack
- Backend: Node.js + Express + Socket.io
- Database: SQLite (dev) / PostgreSQL (prod)
- AI: Ollama (Phi-3 Mini) / Gemini API fallback
- Maps: Google Maps SDK
- Real-time: WebSocket
- Android: Flutter
- Admin: HTML/CSS/JS

## Kontribusi
Project ini masih tahap uji coba. Semua fitur admin-only, user hanya bisa kontrol device sendiri.

## Lisensi
MIT License
