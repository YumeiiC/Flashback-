import 'package:socket_io_client/socket_io_client.dart' as io;

class SocketService {
  static io.Socket? _socket;

  static io.Socket get socket {
    _socket ??= io.io('http://localhost:3000', <String, dynamic>{
      'transports': ['websocket'],
      'autoConnect': true,
    });
    return _socket!;
  }

  static void connect() {
    socket.connect();
    socket.onConnect((_) {
      print('Socket connected');
    });
    socket.onDisconnect((_) {
      print('Socket disconnected');
    });
  }

  static void disconnect() {
    socket.disconnect();
  }

  static void registerDevice(String deviceId) {
    socket.emit('register_device', {'deviceId': deviceId});
  }

  static void sendStatus(Map<String, dynamic> data) {
    socket.emit('device_status', data);
  }

  static void onControlCommand(Function(dynamic) callback) {
    socket.on('control_command', callback);
  }

  static void onStatusUpdate(Function(dynamic) callback) {
    socket.on('status_update', callback);
  }
}
