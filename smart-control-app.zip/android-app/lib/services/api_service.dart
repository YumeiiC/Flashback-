import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ApiService {
  static const String baseUrl = 'http://localhost:3000/api';

  static Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('token');
  }

  static Future<Map<String, String>> getHeaders() async {
    final token = await getToken();
    return {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + (token ?? ''),
    };
  }

  static Future<Map<String, dynamic>> login(String email, String password) async {
    final response = await http.post(
      Uri.parse(baseUrl + '/auth/login'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'email': email, 'password': password}),
    );

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception('Login failed: ' + response.body);
    }
  }

  static Future<Map<String, dynamic>> register(String email, String password, String name) async {
    final response = await http.post(
      Uri.parse(baseUrl + '/auth/register'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'email': email, 'password': password, 'name': name}),
    );

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception('Registration failed: ' + response.body);
    }
  }

  static Future<List<dynamic>> getDevices() async {
    final headers = await getHeaders();
    final response = await http.get(
      Uri.parse(baseUrl + '/devices'),
      headers: headers,
    );

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception('Failed to load devices');
    }
  }

  static Future<Map<String, dynamic>> generatePairingCode(String phoneNumber, String deviceName) async {
    final headers = await getHeaders();
    final response = await http.post(
      Uri.parse(baseUrl + '/pairing/code'),
      headers: headers,
      body: jsonEncode({'phoneNumber': phoneNumber, 'deviceName': deviceName}),
    );

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception('Failed to generate code');
    }
  }

  static Future<Map<String, dynamic>> generateQRCode(String deviceName) async {
    final headers = await getHeaders();
    final response = await http.post(
      Uri.parse(baseUrl + '/pairing/qr'),
      headers: headers,
      body: jsonEncode({'deviceName': deviceName}),
    );

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception('Failed to generate QR');
    }
  }

  static Future<Map<String, dynamic>> sendControlCommand(String deviceId, String action, Map<String, dynamic> params) async {
    final headers = await getHeaders();
    final response = await http.post(
      Uri.parse(baseUrl + '/control/' + deviceId + '/' + action),
      headers: headers,
      body: jsonEncode(params),
    );

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception('Command failed: ' + response.body);
    }
  }

  static Future<List<dynamic>> getLogs() async {
    final headers = await getHeaders();
    final response = await http.get(
      Uri.parse(baseUrl + '/logs'),
      headers: headers,
    );

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception('Failed to load logs');
    }
  }

  static Future<Map<String, dynamic>> chatWithAI(String message, List<Map<String, String>> history) async {
    final headers = await getHeaders();
    final response = await http.post(
      Uri.parse(baseUrl + '/ai/chat'),
      headers: headers,
      body: jsonEncode({'message': message, 'history': history}),
    );

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception('AI chat failed: ' + response.body);
    }
  }
}
