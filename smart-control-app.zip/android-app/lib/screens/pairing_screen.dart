import 'package:flutter/material.dart';
import '../services/api_service.dart';

class PairingScreen extends StatefulWidget {
  const PairingScreen({super.key});

  @override
  State<PairingScreen> createState() => _PairingScreenState();
}

class _PairingScreenState extends State<PairingScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final _phoneController = TextEditingController();
  final _nameController = TextEditingController();
  String? _generatedCode;
  bool _isGenerating = false;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _generateCode() async {
    if (_phoneController.text.isEmpty) {
      _showError('Enter phone number');
      return;
    }

    setState(() => _isGenerating = true);
    try {
      final result = await ApiService.generatePairingCode(
        _phoneController.text,
        _nameController.text.isEmpty ? 'New Device' : _nameController.text,
      );
      setState(() {
        _generatedCode = result['code'];
        _isGenerating = false;
      });
    } catch (e) {
      setState(() => _isGenerating = false);
      _showError('Failed: ' + e.toString());
    }
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.redAccent),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: isDark ? const Color(0xFF0A0A0F) : const Color(0xFFF0F4F8),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Text('Pair Device', style: TextStyle(color: isDark ? Colors.white : const Color(0xFF1A1A2E))),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: const Color(0xFF00D4AA),
          labelColor: const Color(0xFF00D4AA),
          unselectedLabelColor: isDark ? Colors.white54 : Colors.black54,
          tabs: const [
            Tab(icon: Icon(Icons.phone), text: 'Phone Number'),
            Tab(icon: Icon(Icons.qr_code), text: 'QR Code'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildPhoneTab(isDark),
          _buildQRTab(isDark),
        ],
      ),
    );
  }

  Widget _buildPhoneTab(bool isDark) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        children: [
          _buildTextField(_nameController, 'Device Name (optional)', Icons.devices, isDark),
          const SizedBox(height: 16),
          _buildTextField(_phoneController, 'Phone Number', Icons.phone, isDark, TextInputType.phone),
          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            height: 56,
            child: ElevatedButton(
              onPressed: _isGenerating ? null : _generateCode,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF00D4AA),
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              ),
              child: _isGenerating
                  ? const CircularProgressIndicator(color: Colors.white)
                  : const Text('Generate Pairing Code', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ),
          ),
          if (_generatedCode != null) ...[
            const SizedBox(height: 40),
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [Color(0xFF00D4AA), Color(0xFF00A8E8)]),
                borderRadius: BorderRadius.circular(24),
                boxShadow: [BoxShadow(color: const Color(0xFF00D4AA).withOpacity(0.4), blurRadius: 20, spreadRadius: 5)],
              ),
              child: Column(
                children: [
                  const Text('PAIRING CODE', style: TextStyle(color: Colors.white70, fontSize: 14, letterSpacing: 4)),
                  const SizedBox(height: 16),
                  Text(
                    _generatedCode!,
                    style: const TextStyle(color: Colors.white, fontSize: 48, fontWeight: FontWeight.bold, letterSpacing: 8),
                  ),
                  const SizedBox(height: 16),
                  const Text('Valid for 10 minutes', style: TextStyle(color: Colors.white70)),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildQRTab(bool isDark) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        children: [
          _buildTextField(_nameController, 'Device Name (optional)', Icons.devices, isDark),
          const SizedBox(height: 24),
          Row(
            children: [
              Expanded(
                child: ElevatedButton(
                  onPressed: _isGenerating ? null : () async {
                    setState(() => _isGenerating = true);
                    try {
                      await ApiService.generateQRCode(
                        _nameController.text.isEmpty ? 'New Device' : _nameController.text,
                      );
                      setState(() => _isGenerating = false);
                      _showError('QR generated - check server response');
                    } catch (e) {
                      setState(() => _isGenerating = false);
                      _showError('Failed: ' + e.toString());
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF00D4AA),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    padding: const EdgeInsets.symmetric(vertical: 16),
                  ),
                  child: const Text('Generate QR'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: ElevatedButton(
                  onPressed: () {
                    _showError('QR Scanner - implement with qr_code_scanner package');
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF00A8E8),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    padding: const EdgeInsets.symmetric(vertical: 16),
                  ),
                  child: const Text('Scan QR'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildTextField(TextEditingController controller, String label, IconData icon, bool isDark, [TextInputType type = TextInputType.text]) {
    return Container(
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF1A1A2E) : Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 10, offset: const Offset(0, 4))],
      ),
      child: TextField(
        controller: controller,
        keyboardType: type,
        style: TextStyle(color: isDark ? Colors.white : Colors.black87),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(color: isDark ? Colors.white60 : Colors.black54),
          prefixIcon: Icon(icon, color: const Color(0xFF00D4AA)),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
          filled: true,
          fillColor: Colors.transparent,
        ),
      ),
    );
  }
}
