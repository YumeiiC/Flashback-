import 'package:flutter/material.dart';
import '../services/api_service.dart';

class DeviceControlScreen extends StatefulWidget {
  final Map<String, dynamic> device;

  const DeviceControlScreen({super.key, required this.device});

  @override
  State<DeviceControlScreen> createState() => _DeviceControlScreenState();
}

class _DeviceControlScreenState extends State<DeviceControlScreen> {
  bool _isLoading = false;
  String? _lastAction;

  Future<void> _sendCommand(String action) async {
    setState(() {
      _isLoading = true;
      _lastAction = action;
    });

    try {
      await ApiService.sendControlCommand(
        widget.device['device_id'],
        action,
        {},
      );
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Command sent: ' + action.replaceAll('_', ' ').toUpperCase()),
          backgroundColor: const Color(0xFF00D4AA),
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed: ' + e.toString()), backgroundColor: Colors.redAccent),
      );
    } finally {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final device = widget.device;

    return Scaffold(
      backgroundColor: isDark ? const Color(0xFF0A0A0F) : const Color(0xFFF0F4F8),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Text(
          device['name'] ?? 'Device',
          style: TextStyle(color: isDark ? Colors.white : const Color(0xFF1A1A2E)),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: device['status'] == 'online'
                      ? [const Color(0xFF00D4AA), const Color(0xFF00A8E8)]
                      : [Colors.grey, Colors.grey.shade700],
                ),
                borderRadius: BorderRadius.circular(24),
                boxShadow: [
                  BoxShadow(
                    color: (device['status'] == 'online' ? const Color(0xFF00D4AA) : Colors.grey).withOpacity(0.3),
                    blurRadius: 20,
                    spreadRadius: 5,
                  ),
                ],
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.white24,
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Icon(
                          device['status'] == 'online' ? Icons.wifi : Icons.wifi_off,
                          color: Colors.white,
                          size: 32,
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              device['name'] ?? 'Unknown Device',
                              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              (device['status'] ?? 'offline').toUpperCase(),
                              style: const TextStyle(fontSize: 12, color: Colors.white70, letterSpacing: 2),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _buildStatusItem(Icons.battery_full, (device['battery']?.toString() ?? '--') + '%', 'Battery'),
                      _buildStatusItem(Icons.signal_cellular_alt, (device['signal_strength']?.toString() ?? '--'), 'Signal'),
                      _buildStatusItem(Icons.storage, (device['storage_used']?.toString() ?? '--') + 'GB', 'Storage'),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            Text(
              'Remote Controls',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: isDark ? Colors.white : const Color(0xFF1A1A2E),
              ),
            ),
            const SizedBox(height: 16),
            GridView.count(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisCount: 2,
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              childAspectRatio: 1.3,
              children: [
                _buildControlButton('Flashlight ON', Icons.flashlight_on, 'flashlight_on', Colors.amber),
                _buildControlButton('Flashlight OFF', Icons.flashlight_off, 'flashlight_off', Colors.orange),
                _buildControlButton('Play Sound', Icons.volume_up, 'play_sound', Colors.blue),
                _buildControlButton('Stop Sound', Icons.volume_off, 'stop_sound', Colors.indigo),
                _buildControlButton('Capture Photo', Icons.camera_alt, 'capture_photo', Colors.purple),
                _buildControlButton('Screen Record', Icons.videocam, 'start_record', Colors.red),
                _buildControlButton('Vibrate', Icons.vibration, 'vibrate', Colors.teal),
                _buildControlButton('Get Location', Icons.location_on, 'get_location', Colors.green),
              ],
            ),
            const SizedBox(height: 24),
            Text(
              'Quick Actions',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: isDark ? Colors.white : const Color(0xFF1A1A2E),
              ),
            ),
            const SizedBox(height: 16),
            _buildQuickAction(
              'Find My Device',
              'Play sound + flashlight to locate',
              Icons.search,
              () async {
                await _sendCommand('play_sound');
                await Future.delayed(const Duration(seconds: 1));
                await _sendCommand('flashlight_on');
              },
            ),
            _buildQuickAction(
              'Emergency Capture',
              'Take photo + get location',
              Icons.emergency,
              () async {
                await _sendCommand('capture_photo');
                await Future.delayed(const Duration(seconds: 1));
                await _sendCommand('get_location');
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatusItem(IconData icon, String value, String label) {
    return Column(
      children: [
        Icon(icon, color: Colors.white70, size: 24),
        const SizedBox(height: 4),
        Text(value, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white)),
        Text(label, style: const TextStyle(fontSize: 12, color: Colors.white70)),
      ],
    );
  }

  Widget _buildControlButton(String label, IconData icon, String action, Color color) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return GestureDetector(
      onTap: _isLoading ? null : () => _sendCommand(action),
      child: Container(
        decoration: BoxDecoration(
          color: isDark ? const Color(0xFF1A1A2E) : Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 10, offset: const Offset(0, 4))],
          border: _lastAction == action
              ? Border.all(color: const Color(0xFF00D4AA), width: 2)
              : null,
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (_isLoading && _lastAction == action)
              const SizedBox(
                width: 28,
                height: 28,
                child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFF00D4AA)),
              )
            else
              Icon(icon, color: color, size: 28),
            const SizedBox(height: 8),
            Text(
              label,
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: isDark ? Colors.white : Colors.black87,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickAction(String title, String subtitle, IconData icon, VoidCallback onTap) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        onTap: _isLoading ? null : onTap,
        contentPadding: const EdgeInsets.all(16),
        tileColor: isDark ? const Color(0xFF1A1A2E) : Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        leading: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: const Color(0xFF00D4AA).withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(icon, color: const Color(0xFF00D4AA)),
        ),
        title: Text(title, style: TextStyle(fontWeight: FontWeight.bold, color: isDark ? Colors.white : Colors.black87)),
        subtitle: Text(subtitle, style: TextStyle(color: isDark ? Colors.white54 : Colors.black54)),
        trailing: const Icon(Icons.arrow_forward_ios, size: 16, color: Color(0xFF00D4AA)),
      ),
    );
  }
}
